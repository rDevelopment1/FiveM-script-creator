using System;
using System.Threading.Tasks;
using PoliceFunctions_API.Functions;
using CitizenFX.Core;
using CitizenFX.Core.Native;
using CitizenFX.Core.UI;

namespace PROJECTNAME
{
    public class Main : BaseScript
    {
        public Main()
        {
            Tick += OnTick;
            API.RegisterCommand("stop-ped", new Action(StopThatPed), false);
            API.RegisterCommand("release-ped", new Action(ReleaseThatPed), false);
            API.RegisterCommand("arrest", new Action(ArrestThatPed), false);
            API.RegisterCommand("uncuff", new Action(UncuffThatPed), false);
        }
        
        private static void UncuffThatPed()
        {
            PoliceFunctions_API.Functions.ArrestManager.ReleasePed();
            Screen.ShowNotification("Ped uncuffed and released");
        }
        
        private static void ArrestThatPed()
        {
            PoliceFunctions_API.Functions.Arrest.ArrestPed();
        }
        
        private static void ReleaseThatPed()
        {
            PoliceFunctions_API.Functions.PedManager.ReleasePed();
            Screen.ShowNotification("Ped released");
        }
        
        private static void StopThatPed()
        {
            PoliceFunctions_API.Functions.PedManager.StopPed();
        }

        private static async Task OnTick()
        {

        }
    }
}