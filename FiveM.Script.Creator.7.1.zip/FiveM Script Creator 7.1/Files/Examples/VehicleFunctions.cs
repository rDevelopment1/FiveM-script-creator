using System;
using System.Threading.Tasks;
using CitizenFX.Core;
using CitizenFX.Core.Native;
using CitizenFX.Core.UI;

namespace VehicleFunctions
{
    public class Main : BaseScript
    {
        public Main()
        {
            Tick += OnTick;
            API.RegisterCommand("adder", new Action(SpawnAdder), false);
            API.RegisterCommand("dv", new Action(DeleteVehicle), false);
            API.RegisterCommand("repair", new Action(RepairVehicle), false);
            API.RegisterCommand("street", new Action(ShowStreet), false);
        }
        
        private static void ShowStreet()
        {
            var street = World.GetStreetName(Game.Player.Character.Position);
            Screen.ShowNotification("~b~Current Street:~y~ " + street);
        }
        
        private static void RepairVehicle()
        {
            Game.Player.Character.CurrentVehicle.Repair();
        }
        
        private static void DeleteVehicle()
        {
            Game.Player.Character.CurrentVehicle.Delete();
        }
        
        private static void SpawnAdder()
        {
            API.RequestModel((uint)VehicleHash.Adder);
            while (!API.HasModelLoaded((uint)VehicleHash.Adder))
            {
                await BaseScript.Delay(100);
            }
            int Adder = API.CreateVehicle((uint)VehicleHash.Adder, Game.Player.Character.Position.X, Game.Player.Character.Position.Y, Game.Player.Character.Position.Z, Game.Player.Character.Heading, true, true);
        }

        private static async Task OnTick()
        {
            //BEGIN WATERMARK
            API.SetTextScale(0.3f, 0.3f);
            API.SetTextFont(0);
            API.SetTextProportional(true);
            API.SetTextColour((int)byte.MaxValue, (int)byte.MaxValue, (int)byte.MaxValue, (int)byte.MaxValue);
            API.SetTextOutline();
            API.SetTextEntry("STRING");
            API.AddTextComponentString("ECDoJ Vehicle Functions");
            API.DrawText(0.0f, 0.0f);
            //END WATERMARK
        }
    }
}