var street = World.GetStreetName(Game.Player.Character.Position);
			Screen.ShowNotification("~b~Current Street:~y~ " + street);