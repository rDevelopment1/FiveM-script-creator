var NEWITEM = new UIMenuItem("Item Title", "Item description");
			SUBMENU.AddItem(NEWITEM);
			SUBMENU.OnItemSelect += async (sender, item, index) =>
			{
				if (item == NEWITEM)
				{
					//CODE HERE
				}
			};