var SubMenuName = _menuPool.AddSubMenu(menu, "SUB MENU BUTTON TEXT");
            for (int i = 0; i < 1; i++) ;

            SubMenuName.MouseEdgeEnabled = false;
            SubMenuName.ControlDisablingEnabled = false;