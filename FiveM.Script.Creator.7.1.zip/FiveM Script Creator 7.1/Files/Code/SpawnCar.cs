			//Convert to hash
            var modelName = "so1";
            var modelHash = (uint)API.GetHashKey(modelName);

            //Check if model is valid
            if (API.IsModelInCdimage(modelHash))
            {
                //Request Model
                API.RequestModel(modelHash);

                //Check if model has loaded
                while (!API.HasModelLoaded(modelHash))
                {
                    await Delay(0);
                }

                //Delete vehicle if player is already in one
                if (Game.Player.Character.IsInVehicle())
                {
                    Game.Player.Character.CurrentVehicle.Delete();
                }

                //Spawn Vehicle
                var vehicle = API.CreateVehicle(modelHash, Game.Player.Character.Position.X, Game.Player.Character.Position.Y, Game.Player.Character.Position.Z, Game.Player.Character.Heading, true, true);
            }
            else
            {
                //Show notification that model does not exist
                Screen.ShowNotification("~r~Model does not exist");
            }