API.SetNotificationTextEntry("STRING");
			API.SetNotificationColorNext(4);
			API.AddTextComponentString("MAIN TEXT HERE");
			API.SetTextScale(0.5f, 0.5f);
			API.SetNotificationMessage("CHAR_YOUTUBE", "CHAR_YOUTUBE", false, 0, "TITLE TEXT HERE", "SUBTITLE TEXT HERE");
			API.DrawNotification(true, false);