private static void playerSpawned()
		{
			//CODE FOR WHEN PLAYER SPAWNS GOES HERE
		}