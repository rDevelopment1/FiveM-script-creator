private static void CommandAction()
		{
			//COMMAND CODE GOES HERE
		}