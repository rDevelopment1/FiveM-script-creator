//BEGIN WATERMARK
			API.SetTextScale(0.3f, 0.3f);
			API.SetTextFont(0);
			API.SetTextProportional(true);
			API.SetTextColour((int)byte.MaxValue, (int)byte.MaxValue, (int)byte.MaxValue, (int)byte.MaxValue);
			API.SetTextOutline();
			API.SetTextEntry("STRING");
			API.AddTextComponentString("WATERMARK TEXT HERE");
			API.DrawText(0.0f, 0.0f);
			//END WATERMARK