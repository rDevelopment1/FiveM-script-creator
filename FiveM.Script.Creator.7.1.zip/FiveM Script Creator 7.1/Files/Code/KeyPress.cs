if (API.IsControlJustPressed(0, 166)) //THIS IS THE F5 KEY. See HELP > FiveM Documents > Controls (ONLY REPLACE THE 166)
			{
				//CODE GOES HERE
			}