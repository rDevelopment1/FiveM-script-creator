resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

files {
	'PoliceFunctions-API.dll'
}

client_scripts {
	'PROJECTNAME.net.dll'
}