﻿using System;
using System.Threading.Tasks;
using PoliceFunctions_API.Functions;
using CitizenFX.Core;
using CitizenFX.Core.Native;
using CitizenFX.Core.UI;

namespace PROJECTNAME
{
    public class Main : BaseScript
    {
		public static string Author = "AUTHOR NAME";
		public static string ModName = "MOD NAME";
		public static string Version = "CURRENT VERSION";
		
        public Main()
        {
            Tick += OnTick;
        } // <<<< THIS IS YOUR CLOSING MAIN BRACKET

        private static async Task OnTick()
        {

        }
    }
}